window.onload = function(){
   $("#physGrav").val("0.01");
   $("#physRest").val("1.0");

   GL_Main();
   Control_Main();
};
