var express = require("express");
var bodyParser = require("body-parser");
var fs = require("fs");

var app = express();
app.use(bodyParser.urlencoded({
  extended: true
}));

app.use(bodyParser.json());

var _messages = [];


app.get("/*", function(req, res) {
  var data = {};
  if ('query' in req)
    data = req.query;

  var url = req.url;
  if (url === "/")
    url += "index.html"

  if (fs.existsSync("server" + url)) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(fs.readFileSync("server" + url));
  }
  else {
    res.writeHead(404);
    res.end();
  }
});

app.post("/api", function(req, res) {
  console.log(req.body);

  var action = req.body.action;

  if (action === 'post') {
      _messages.push(req.body.message);

      res.writeHead(200, {'Content-Type': 'text/json'});
      res.end(JSON.stringify({success: true}));
  }
  else if (action === 'list') {
    res.writeHead(200, {'Content-Type': 'text/json'});
    res.end(JSON.stringify({success: true, messages: _messages}));
  }
  else {
    res.writeHead(200, {'Content-Type': 'text/json'});
    res.end(JSON.stringify({success: false}));
  }
});

app.listen(3000, function() {
  console.log("Server running at localhost:3000");
});
